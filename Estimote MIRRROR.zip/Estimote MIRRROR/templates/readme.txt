Templates examples

You can modify examples in this directory and then copy them to templates directory.
After Mirror is rebooted, new templates will be applied and templates directory will be empty.
